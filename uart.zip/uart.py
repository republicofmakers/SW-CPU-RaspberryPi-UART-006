#!/usr/bin/env python3
import time
from smbus2 import SMBus, i2c_msg
import serial
import sys

SHT4X_ADDR = 0x44
MEASURE_HIGH_PRECISION = 0xFD
READ_LEN = 6

def crc8_sensirion(data_bytes):
    crc = 0xFF
    for b in data_bytes:
        crc ^= b
        for _ in range(8):
            crc = ((crc << 1) ^ 0x31) & 0xFF if (crc & 0x80) else ((crc << 1) & 0xFF)
    return crc

def open_i2c_bus():
    for cand in (1, 0, 3):
        try:
            return SMBus(cand), cand
        except Exception:
            continue
    raise RuntimeError("No usable I2C bus (tried 1,0,3)")

def sht4x_read_once(bus, addr=SHT4X_ADDR):
    bus.i2c_rdwr(i2c_msg.write(addr, [MEASURE_HIGH_PRECISION]))
    time.sleep(0.015)
    rx = i2c_msg.read(addr, READ_LEN)
    bus.i2c_rdwr(rx)
    d = list(rx)

    if crc8_sensirion(d[0:2]) != d[2]:
        raise ValueError("CRC error (temp)")
    if crc8_sensirion(d[3:5]) != d[5]:
        raise ValueError("CRC error (humidity)")

    t_raw = (d[0] << 8) | d[1]
    h_raw = (d[3] << 8) | d[4]
    temp_c = -45.0 + (175.0 * t_raw / 65535.0)
    rh = 100.0 * h_raw / 65535.0
    return temp_c, rh

def sht4x_read(bus, addr=SHT4X_ADDR, attempts=3, backoff=0.05):
    last_err = None
    for _ in range(attempts):
        try:
            return sht4x_read_once(bus, addr)
        except OSError as e:
            last_err = e
            time.sleep(backoff)
        except Exception as e:
            last_err = e
            break
    raise RuntimeError(f"Failed SHT4x read: {last_err}")

def open_uart(port="/dev/serial0", baud=115200, timeout=1):
    return serial.Serial(port=port, baudrate=baud, timeout=timeout)

def main():
    bus, busnum = open_i2c_bus()
    ser = open_uart("/dev/serial0", 115200, 1)

    print(f"I2C bus {busnum} opened; SHT4x at 0x{SHT4X_ADDR:02X}", file=sys.stderr)
    ser.write(b"SHT4x Sensor Monitor\r\n")
    ser.write(b"---------------------\r\n")

    try:
        while True:
            try:
                t_c, rh = sht4x_read(bus, SHT4X_ADDR)
                line = f"Temp: {t_c:5.2f} °C   Humidity: {rh:5.2f} %RH\r\n"
                sys.stdout.write(line)   # local debug
                ser.write(line.encode()) # UART output
            except Exception as e:
                err_line = f"Error: {e}\r\n"
                sys.stderr.write(err_line)
                ser.write(err_line.encode())
            time.sleep(1.0)
    finally:
        ser.close()
        bus.close()

if __name__ == "__main__":
    main()
